CREATE TABLE "City" (

	"identifier" INTEGER NOT NULL,
	
	"denomination" VARCHAR(40) NOT NULL,
	
	"state" INTEGER NOT NULL

);
