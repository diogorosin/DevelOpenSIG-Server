CREATE TABLE "Type" (

	"identifier" INTEGER NOT NULL,

	"denomination" VARCHAR(100)

);