CREATE TABLE "Country" (

	"identifier" INTEGER NOT NULL,

	"denomination" VARCHAR(50) NOT NULL,

	"acronym" VARCHAR(3) NOT NULL

);
