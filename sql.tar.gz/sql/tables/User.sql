CREATE TABLE "User" (

    "individual" INTEGER NOT NULL,

    "login" VARCHAR(254) NOT NULL,

    "password" VARCHAR(64) NOT NULL,

    "lastLoggedIn" INTEGER

);
