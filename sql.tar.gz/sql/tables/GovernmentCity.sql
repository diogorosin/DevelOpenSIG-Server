CREATE TABLE "GovernmentCity" (

	"government" INTEGER NOT NULL,

	"city" INTEGER NOT NULL

);
