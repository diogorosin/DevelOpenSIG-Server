CREATE TABLE "Government" (

	"organization" INTEGER NOT NULL

);
