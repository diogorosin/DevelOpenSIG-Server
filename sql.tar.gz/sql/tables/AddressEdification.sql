CREATE TABLE "AddressEdification" (

	"address" INTEGER NOT NULL,

	"edification" INTEGER NOT NULL,

	"type" INTEGER NOT NULL,

	"reference" VARCHAR(10),

	"from" TIMESTAMP NOT NULL,

	"to" TIMESTAMP

);