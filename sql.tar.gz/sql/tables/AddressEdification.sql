CREATE TABLE "AddressEdification" (

	"address" INTEGER NOT NULL,

	"edification" INTEGER NOT NULL,

	"type" INTEGER NOT NULL,

	"reference" VARCHAR(10)

);