CREATE TABLE "ModifiedAddressEdification" (

	"modifiedAddress" INTEGER NOT NULL,

	"edification" INTEGER NOT NULL,

	"type" INTEGER NOT NULL,

	"reference" VARCHAR(10),

    "from" TIMESTAMP,

	"to" TIMESTAMP

);