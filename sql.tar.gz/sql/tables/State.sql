CREATE TABLE "State" (

	"identifier" INTEGER NOT NULL,
     
	"denomination" VARCHAR(20) NOT NULL,
	
	"acronym" VARCHAR(2) NOT NULL,
     
	"country" INTEGER NOT NULL

);
