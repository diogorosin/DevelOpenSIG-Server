CREATE TABLE "Organization" (

    "subject" INTEGER NOT NULL,

    "denomination" VARCHAR(150) NOT NULL,

    "fancyName" VARCHAR(32)

);