CREATE TABLE "AddressEdificationDweller" (

	"address" INTEGER NOT NULL,

    "edification" INTEGER NOT NULL,

	"dweller" INTEGER NOT NULL,

	"subject" INTEGER NOT NULL,

	"from" TIMESTAMP NOT NULL,

	"to" TIMESTAMP,

	"verifiedAt" TIMESTAMP NOT NULL,

	"verifiedBy" INTEGER NOT NULL

);