CREATE TABLE "AddressEdificationDweller" (

	"address" INTEGER NOT NULL,

    "edification" INTEGER NOT NULL,

	"dweller" INTEGER NOT NULL,

	"individual" INTEGER NOT NULL,

	"from" TIMESTAMP NOT NULL,

	"to" TIMESTAMP

);