/* CRIA PROCEDIMENTOS */
\i functions/ClearExpiredTokenJob.sql 
