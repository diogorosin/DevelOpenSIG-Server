/* CRIA PROCEDIMENTOS */
\i functions/ClearExpiredToken.sql 
\i functions/FindIndividualByDocuments.sql
\i functions/ImportModifiedAddress.sql