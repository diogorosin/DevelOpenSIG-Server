DROP FUNCTION IF EXISTS ClearExpiredToken;
DROP FUNCTION IF EXISTS FindIndividualByDocuments;
DROP FUNCTION IF EXISTS ImportModifiedAddress;