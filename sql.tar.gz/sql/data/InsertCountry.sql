-- FONTE.....: WEB (http://www.inf.ufrgs.br/~cabral/countryes.html)

DELETE FROM "Country";
INSERT INTO "Country" ("identifier", "denomination", "acronym") VALUES (1, 'Brasil', 'BRA');
