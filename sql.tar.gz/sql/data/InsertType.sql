DELETE FROM "Type";
INSERT INTO "Type" ("identifier", "denomination") VALUES (01, 'Casa');
INSERT INTO "Type" ("identifier", "denomination") VALUES (02, 'Apartamento');
INSERT INTO "Type" ("identifier", "denomination") VALUES (03, 'Sala Comercial');
INSERT INTO "Type" ("identifier", "denomination") VALUES (04, 'Propriedade Rural');
INSERT INTO "Type" ("identifier", "denomination") VALUES (05, 'Outro');